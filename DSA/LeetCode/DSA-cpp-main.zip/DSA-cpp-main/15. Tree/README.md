# Hacktoberfest 2021 <br/> ![Open Source Love](https://badges.frapsoft.com/os/v2/open-source.svg?v=103) ![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)  [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-green.svg)](.github/CONTRIBUTING.md) 
![image](https://user-images.githubusercontent.com/64991656/135403993-8436cfd2-5314-4c03-8509-d33e51c565b2.png)

# Table of Contents
- [Trees](1.%20Trees.cpp)
- [Centroid of Tree](2.%20Centroid_of_Tree.cpp)
- [ZigZag Traversal of Tree](3.%20Binary_Tree_ZigZag_Traversal.cpp)
- [Least Common Ancestors (LCA)](4.%20Least_Common_Ancestor.cpp)
