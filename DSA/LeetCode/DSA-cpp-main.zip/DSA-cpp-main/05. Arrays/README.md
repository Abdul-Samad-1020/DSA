# DSA 60 days 
## Aug 3


### Arrays

<!-- <hr>
-> Read from :- <a href="https://www.geeksforgeeks.org/binary-search">Binary Search</a>
<hr>
 -->
Question 1:- <a href="https://practice.geeksforgeeks.org/problems/reverse-an-array/0" >Reverse an array</a><br>
Question 2:- <a href="https://practice.geeksforgeeks.org/problems/rotate-array-by-n-elements-1587115621/1" >Rotate</a><br>
Question 3:- <a href="https://practice.geeksforgeeks.org/problems/reverse-a-string/1" >Reverse string</a><br>
Question 4:- <a href="https://practice.geeksforgeeks.org/problems/3-sum-closest/1" > 3 sum closest</a><br>
Question 5:- <a href="https://practice.geeksforgeeks.org/problems/stock-buy-and-sell-1587115621/1" >stock buy sell</a><br>


1. <a href="https://practice.geeksforgeeks.org/problems/union-of-two-sorted-arrays-1587115621/1/">union-of-two-sorted-arrays</a>
2. <a href="https://practice.geeksforgeeks.org/problems/intersection-of-two-sorted-array-1587115620/1/">intersection-of-two-sorted-array</a>
3. <a href="https://practice.geeksforgeeks.org/problems/minimum-swaps/1/">minimum-swaps</a><br>
4. <a href="https://practice.geeksforgeeks.org/problems/minimum-platforms-1587115620/1/">minimum-platforms</a>
5. <a href="https://practice.geeksforgeeks.org/problems/median-of-two-sorted-arrays1618/1/">median-of-two-sorted-arrays</a>
6. <a href="https://practice.geeksforgeeks.org/problems/sort-an-array-of-0s-1s-and-2s4231/1/">sort-an-array-of-0s-1s-and-2s</a>


1. <a href="https://practice.geeksforgeeks.org/problems/first-repeating-element4018/1/">first-repeating-element</a>
2. <a href="https://practice.geeksforgeeks.org/problems/find-immediate-smaller-than-x/1/">find-immediate-smaller-than-x</a>
3. <a href="https://practice.geeksforgeeks.org/problems/kadanes-algorithm-1587115620/1/">kadanes-algorithm</a><br>
4. <a href="https://practice.geeksforgeeks.org/problems/smallest-positive-missing-number3051/1/">smallest-positive-missing-number</a>
5. <a href="https://practice.geeksforgeeks.org/problems/rearrange-an-array-with-o1-extra-space3142/1/">rearrange-an-array-with-o1-extra-space</a>
6. [merge without extra space](https://practice.geeksforgeeks.org/problems/merge-two-sorted-arrays-1587115620/1/)


