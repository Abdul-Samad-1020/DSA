# Aug 9
## String

1.<a href="https://practice.geeksforgeeks.org/problems/reverse-words-in-a-given-string5459/1">reverse words in string</a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/longest-common-prefix-in-an-array5129/1">longest common prefix </a><br>
3.<a href="https://practice.geeksforgeeks.org/problems/roman-number-to-integer3201/1">roman umber to integer</a><br>
4.<a href="https://practice.geeksforgeeks.org/problems/longest-prefix-suffix/0">longest-prefix-suffix</a><br>
