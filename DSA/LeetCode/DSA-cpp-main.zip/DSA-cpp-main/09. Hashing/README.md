# Aug 7
## Hashing

1.<a href="https://practice.geeksforgeeks.org/problems/key-pair5616/1">key-pair</a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/top-k-frequent-elements-in-array/1">top-k-frequent-elements-in-array</a><br>
3.<a href="https://practice.geeksforgeeks.org/problems/intersection-of-two-arrays2404/1">intersection-of-two-arrays</a><br>
4.<a href="https://practice.geeksforgeeks.org/problems/triplet-sum-in-array-1587115621/1">triplet-sum-in-array</a><br>
