# DSA 60 days 


<!-- <hr>
Starting from Algorithms to dynamic programming

<hr><center>
-> Each day 5 problems <br>
-> July 12 - September 10 <br>
-> For beginners and intermediates <br></center>
<hr>
<img src="Sushreesatarupa/DSA-60DAYS/IMG_20210710_014552.jpg">
 -->
 
11. Linked list
12. Stack
13. Queue
