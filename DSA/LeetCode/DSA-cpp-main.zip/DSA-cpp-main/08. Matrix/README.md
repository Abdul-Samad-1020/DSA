# Aug 26
## Matrix


1. <a href="https://practice.geeksforgeeks.org/problems/adding-two-matrices3512/1/">adding-two-matrices</a>
2. <a href="https://practice.geeksforgeeks.org/problems/multiply-the-matrices-1587115620/1/">multiply-the-matrices</a>
3. <a href="https://practice.geeksforgeeks.org/problems/determinant-of-a-matrix-1587115620/1/">determinant-of-a-matrix</a><br>
4. <a href="https://practice.geeksforgeeks.org/problems/transpose-of-matrix-1587115621/1/">transpose-of-matrix</a>
1. <a href="https://practice.geeksforgeeks.org/problems/rotate-by-90-degree-1587115621/1/">rotate-by-90-degree</a>
2. <a href="https://practice.geeksforgeeks.org/problems/spirally-traversing-a-matrix-1587115621/1/">spirally-traversing-a-matrix</a>
3. <a href="https://practice.geeksforgeeks.org/problems/search-in-a-matrix-1587115621/1/">search-in-a-matrix</a><br>
4. <a href="https://practice.geeksforgeeks.org/problems/max-rectangle/1/">max-rectangle</a>
