# DSA 60 days 
## Aug 1 

<hr>

## Bit manipulation
## Arrays

<hr>
-> Read from :- <a href="https://www.geeksforgeeks.org/all-about-bit-manipulation/">Bit manipulation</a>
<hr>

Question 1:- <a href="https://practice.geeksforgeeks.org/problems/set-bits0143/1" > Number of 1 Bits</a><br>
Question 2:- <a href="https://practice.geeksforgeeks.org/problems/sum-of-two-numbers-without-using-arithmetic-operators/0/?fbclid=IwAR1A_1ONHs__SWLPe77raUMJWVLCGJfEC10MfZYupmjwGpneJV9eTo9K9l8" >Sum of two numbers without using arithmetic operators </a><br>
Question 3:- <a href="https://practice.geeksforgeeks.org/problems/check-whether-k-th-bit-is-set-or-not-1587115620/1" >Check whether K-th bit is set or not </a><br>
Question 4:- <a href="https://practice.geeksforgeeks.org/problems/longest-consecutive-1s-1587115620/1" > Longest Consecutive 1's</a><br>
Question 5:- <a href="https://practice.geeksforgeeks.org/problems/division-without-using-multiplication-division-and-mod-operator/0/" > Division without using multiplication, division and mod operator</a><br>
Question 6:- <a href="https://practice.geeksforgeeks.org/problems/spirally-traversing-a-matrix-1587115621/1" >Spirally traversing a matrix</a><br>
Question 7:- <a href="https://practice.geeksforgeeks.org/problems/rotate-array-by-n-elements-1587115621/1" > Rotate Array</a><br>
Question 8:- <a href="https://practice.geeksforgeeks.org/problems/search-in-a-matrix17201720/1" > Search in a matrix</a>

