# Aug 24
## sorting


1. <a href="https://practice.geeksforgeeks.org/problems/square-root/1/">square-root</a>
2. <a href="https://practice.geeksforgeeks.org/problems/binary-search-1587115620/1/">binary-search</a>
3. <a href="https://practice.geeksforgeeks.org/problems/peak-element/1/">peak-element</a><br>
4. <a href="https://practice.geeksforgeeks.org/problems/search-in-a-rotated-array0959/1/">search-in-a-rotated-array</a>
5. <a href="https://practice.geeksforgeeks.org/problems/merge-sort/1/">merge-sort</a>
6. <a href="https://practice.geeksforgeeks.org/problems/quick-sort/1/">quick sort</a>
7. <a href="https://practice.geeksforgeeks.org/problems/sort-an-array-of-0s-1s-and-2s4231/1">Sort an array of 0s, 1s and 2s</a>

