# Aug 13
## Linklist

1.<a href="https://practice.geeksforgeeks.org/problems/merge-two-sorted-linked-lists/1"> merge-two-sorted-linked-lists</a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/reverse-a-linked-list/1">reverse-a-linked-list</a><br>
3.<a href="https://practice.geeksforgeeks.org/problems/delete-without-head-pointer/1">delete-without-head-pointer</a><br>

1.<a href="https://practice.geeksforgeeks.org/problems/add-two-numbers-represented-by-linked-lists/1">add-two-numbers-represented-by-linked-lists</a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/finding-middle-element-in-a-linked-list/1">finding-middle-element-in-a-linked-list</a><br>
3.<a href="https://practice.geeksforgeeks.org/problems/check-if-linked-list-is-pallindrome/1">check-if-linked-list-is-pallindrome</a><br>

1.<a href="https://practice.geeksforgeeks.org/problems/rearrange-a-linked-list/1">rearrange-a-linked-list</a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/remove-loop-in-linked-list/1">remove-loop-in-linked-list</a><br>
3.<a href="https://practice.geeksforgeeks.org/problems/sort-a-linked-list/1">sort-a-linked-list</a><br>

1.<a href="https://practice.geeksforgeeks.org/problems/rearrange-a-linked-list/1">rearrange-a-linked-list</a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/remove-loop-in-linked-list/1">remove-loop-in-linked-list</a><br>
3.<a href="https://practice.geeksforgeeks.org/problems/sort-a-linked-list/1">sort-a-linked-list</a><br>

1.<a href="https://www.geeksforgeeks.org/function-to-check-if-a-singly-linked-list-is-palindrome/">function-to-check-if-a-singly-linked-list-is-palindrome</a><br>
2.<a href="https://www.geeksforgeeks.org/write-a-function-to-get-the-intersection-point-of-two-linked-lists/">write-a-function-to-get-the-intersection-point-of-two-linked-lists</a><br>
3.<a href="https://www.geeksforgeeks.org/detect-loop-in-a-linked-list/">detect-loop-in-a-linked-list</a><br>
4.<a href="https://www.geeksforgeeks.org/detect-and-remove-loop-in-a-linked-list">detect-and-remove-loop-in-a-linked-list</a><br>


1.<a href="https://practice.geeksforgeeks.org/problems/intersection-point-in-y-shapped-linked-lists/1">intersection-point-in-y-shapped-linked-lists/1</a><br>
2.<a href="https://practice.geeksforgeeks.org/problems/rotate-a-linked-list/1">rotate-a-linked-list/1</a><br>
4.<a href="https://practice.geeksforgeeks.org/problems/flattening-a-linked-list/1">flattening-a-linked-list</a><br>


