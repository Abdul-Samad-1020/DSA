# DSA 60 days 
## Aug 2


### Arrays
### Binary Search

<hr>
-> Read from :- <a href="https://www.geeksforgeeks.org/binary-search">Binary Search</a>
<hr>

Question 1:- <a href="https://practice.geeksforgeeks.org/problems/trapping-rain-water-1587115621/1" >Trapping rainwater</a><br>
Question 2:- <a href="https://practice.geeksforgeeks.org/problems/first-and-last-occurrences-of-x3116/1" >Find first and last positions of and element in an array</a><br>
Question 3:- <a href="https://practice.geeksforgeeks.org/problems/number-of-occurrence/0" >count number of accourance in a sorted array </a><br>
Question 4:- <a href="https://practice.geeksforgeeks.org/problems/check-perfect-square/0" > check if given number is a perfect square</a><br>
Question 5:- <a href="https://practice.geeksforgeeks.org/problems/square-root/1" > find square root of a number rounded to floor</a><br>

