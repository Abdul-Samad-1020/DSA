# DSA 60 days 


## Array Data Structure
<!-- 
<ul>
  <li> Intro to arrays </li>
  <li> fixed size arrays </li>
  <li> dynamic arrays </li>
  <li> searching </li>
  <li> insertion </li>
  <li> deletion </li>
  <li> reversal </li>
</ul>
<hr>
Download the file for arrays theory. <br><br>

[Download PDF from here](https://github.com/Sushreesatarupa/DSA-60Days/blob/main/Day07/Practice%20_%20GeeksforGeeks%20_%20A%20computer%20science%20portal%20for%20geeks?raw=true)

<img src="https://github.com/Sushreesatarupa/DSA-60Days/blob/main/Day07/IMG_20210714_024650.jpg"> 
 -->
 
 7. Searching
