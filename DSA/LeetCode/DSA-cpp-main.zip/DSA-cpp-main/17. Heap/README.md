# DSA 60 days 
<hr>
July 15
<hr><p style="text-align :center">
-> We will revise the contents of day 1-3 <br><br>
-> We will solve the remaining questions of the past 3 days and not be doing any new questions.<br> <br>
-> We have a session on "Getting started with GitHub and opensource" at 5PM. So, do register!<br></center> <br>
<br><a href=" https://organize.mlh.io/participants/events/7224-getting-started-with-github"> Click here to Register ! <a>
<hr><p>
<img src="https://github.com/Sushreesatarupa/DSA-60Days/blob/main/Day04/IMG-20210713-WA0122.jpg">

