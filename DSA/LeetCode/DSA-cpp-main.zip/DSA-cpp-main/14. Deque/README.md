# DSA DAY 1


<hr>
CPP Fundamentals

<hr><center>
 July 12 <br>
<hr>
<img src="https://github.com/Sushreesatarupa/DSA-60Days/blob/main/Day01/20210712_002834_0000.png">
<img src="https://github.com/Sushreesatarupa/DSA-60Days/blob/main/Day01/20210712_132943_0000.png">
